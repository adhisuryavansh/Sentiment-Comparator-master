# Sentiment-Comparator

This is a simple Python code which calculates and compare sentiments of twitter users toward keywords provided by user, and through that comparison the program decides which keyword is more preferred by world.

# Requirments

1. pip install tweepy
2. pip install textblob
3. pip install preprocessor
4. pip install typing

# Demonstration

<img src="/example img.png" alt="My cool logo"/>
